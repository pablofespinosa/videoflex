<div align="center">

# ⚡ VideoFlex

### Descargador Universal de Videos y Torrents

![Version](https://img.shields.io/badge/versión-1.5.0%20Enhanced-6366f1?style=for-the-badge)
![Python](https://img.shields.io/badge/Python-3.10%2B-3b82f6?style=for-the-badge&logo=python&logoColor=white)
![Flet](https://img.shields.io/badge/Flet-0.21%2B-8b5cf6?style=for-the-badge)
![Platform](https://img.shields.io/badge/plataforma-Windows%20%7C%20Linux%20%7C%20macOS-10b981?style=for-the-badge)
![License](https://img.shields.io/badge/licencia-Propietaria-64748b?style=for-the-badge)

**Desarrollado por Pablo F. Espinosa · PFE Computación © 2025-2026**

</div>

---

## 📋 Descripción

VideoFlex es una aplicación de escritorio multiplataforma que permite descargar videos de más de 1000 sitios web y gestionar torrents de forma integrada, todo desde una interfaz moderna y oscura construida con [Flet](https://flet.dev/) (Flutter para Python).

---

## ✨ Características principales

### 🎥 Descarga de videos
- Soporte para **YouTube, TikTok, Instagram, Twitter/X, Facebook, Vimeo, Dailymotion, Reddit** y más de 1000 sitios vía yt-dlp
- Calidades seleccionables: **720p, 1080p, 1440p, 2160p (4K), best**
- Sistema de cola con descargas **concurrentes configurables**
- Soporte de **cookies** para videos que requieren login
- Detección automática de URLs desde el portapapeles
- Historial de descargas con búsqueda, filtros y exportación

### 🧲 Gestión de torrents
- Integración completa con **qBittorrent WebUI**
- Añadir torrents por **enlace magnet** directamente desde la app
- Monitoreo en tiempo real de velocidad, progreso y estado
- Accesos directos a sitios: **LimeTorrents, 1377x, YTS, ThePirateBay**
- Notificaciones al completar descargas

### 📊 Dashboard
- Vista general de velocidades de descarga/subida
- Monitor de espacio en disco en tiempo real
- Actividad reciente unificada (videos + torrents)
- Acciones rápidas desde un solo lugar

### ⚙️ Configuración
- Rutas de descarga personalizables por tipo (video / torrent)
- Número máximo de descargas simultáneas
- Conexión a qBittorrent (host, puerto, usuario, contraseña)
- Tema visual: **oscuro / claro**
- Gestión de cookies del navegador

---

## 🏗️ Arquitectura del código

```
videoflex_v3-1.py  (4600+ líneas)
│
├── AppLogger               — Sistema de logging con rotación automática (5MB)
├── NotificationManager     — Notificaciones nativas del sistema operativo
├── DiskSpaceMonitor        — Monitor de espacio en disco multiplataforma
├── DownloadStatus (Enum)   — Estados: QUEUED, DOWNLOADING, COMPLETED, ERROR, CANCELLED, PAUSED
├── VideoDownload           — Dataclass con metadatos de cada descarga
├── AppConfig               — Configuración persistente en JSON (~/.videoflex_config.json)
├── ClipboardHistory        — Historial del portapapeles con deduplicación
├── DownloadHistory         — Historial persistente con exportación CSV/JSON
├── QBittorrentAPI          — Cliente HTTP para la WebUI de qBittorrent
├── VideoManager            — Gestor de descargas con cola y concurrencia
└── VideoFlexApp            — Clase principal de la UI (Flet/Flutter)
    ├── _build_dashboard_compact()   — Dashboard con stats en tiempo real
    ├── _build_torrents_compact()    — Gestión de torrents
    ├── _build_videos_compact()      — Descarga de videos
    ├── _build_downloads_compact()   — Lista de descargas activas
    ├── _build_history_compact()     — Historial con búsqueda y filtros
    ├── _build_settings_compact()    — Configuración de la app
    └── _build_about_compact()       — Información y créditos
```

---

## 🖥️ Requisitos

### Sistema operativo
- Windows 10 / 11 (x64)
- Linux (Ubuntu 20.04+, Debian 11+, Arch Linux, Fedora 36+)
- macOS 12+

### Python
- **Python 3.10 o superior**

### Dependencias Python
```
flet>=0.21.0
requests
pyperclip
psutil
yt-dlp
```

### Herramientas externas (recomendadas)
| Herramienta | Para qué | Instalación |
|---|---|---|
| **ffmpeg** | Mezclar video+audio en descargas | [ffmpeg.org](https://ffmpeg.org) |
| **qBittorrent** | Gestión de torrents | [qbittorrent.org](https://www.qbittorrent.org) |
| **VLC** | Reproductor multimedia | [videolan.org](https://www.videolan.org) |

---

## 🚀 Instalación y ejecución

### Opción 1 — Ejecutar directamente con Python

```bash
# 1. Clonar el repositorio
git clone https://github.com/pfe-computacion/videoflex.git
cd videoflex

# 2. Crear entorno virtual
python -m venv venv
source venv/bin/activate        # Linux/macOS
venv\Scripts\activate           # Windows

# 3. Instalar dependencias
pip install flet requests pyperclip psutil yt-dlp

# 4. Ejecutar
python videoflex_v3-1.py
```

### Opción 2 — Instalador nativo por plataforma

Usá los scripts del directorio `installers/` para generar paquetes nativos:

#### 🪟 Windows 10/11 — genera `.exe`
```cmd
cd installers\windows\
build_windows.bat
```
> Requiere Python 3.10+ con "Add to PATH". Opcionalmente Inno Setup para el instalador completo.

#### 🔷 Arch Linux / CachyOS / Manjaro — genera `.pkg.tar.zst`
```bash
cd installers/arch/
chmod +x build_arch.sh && ./build_arch.sh
sudo pacman -U videoflex-1.5.0-1-x86_64.pkg.tar.zst
```

#### 🟠 Debian / Ubuntu / Mint — genera `.deb`
```bash
cd installers/debian/
chmod +x build_debian.sh && ./build_debian.sh
sudo dpkg -i videoflex_1.5.0_amd64.deb
```

#### 🔴 Fedora / RHEL / openSUSE — genera `.rpm`
```bash
cd installers/rpm/
chmod +x build_rpm.sh && ./build_rpm.sh
sudo dnf install ./videoflex-1.5.0-1.fc*.x86_64.rpm
```

---

## ⌨️ Atajos de teclado

| Atajo | Acción |
|---|---|
| `F1` | Ayuda |
| `Ctrl+N` | Nueva descarga de video |
| `Ctrl+D` | Ir al Dashboard |
| `Ctrl+T` | Ir a Torrents |
| `Ctrl+V` | Ir a Videos |
| `Ctrl+H` | Ir al Historial |
| `Ctrl+S` | Guardar configuración |
| `Ctrl+R` | Refrescar sección actual |
| `Ctrl+Q` | Salir de la aplicación |
| `Del` | Cancelar descarga seleccionada |
| `Esc` | Cerrar diálogo abierto |

---

## ⚙️ Configuración de qBittorrent

Para usar la integración de torrents necesitás habilitar la WebUI en qBittorrent:

1. Abrí qBittorrent → **Herramientas → Opciones → Interfaz Web**
2. Marcá **"Habilitar interfaz web"**
3. Puerto por defecto: `8080`
4. Configurá usuario y contraseña
5. En VideoFlex → **Configuración → qBittorrent** ingresá los mismos datos

---

## 📁 Archivos generados por la app

| Archivo | Ubicación | Contenido |
|---|---|---|
| `videoflex_config.json` | `~/.videoflex_config.json` | Configuración de la app |
| `videoflex_history.json` | `~/.videoflex_history.json` | Historial de descargas |
| `videoflex_app.log` | `~/.videoflex_app.log` | Log general (rotación a 5MB) |
| `videoflex_errors.log` | `~/.videoflex_errors.log` | Log de errores |

---

## 🗂️ Estructura del repositorio

```
videoflex/
├── videoflex_v3-1.py          ← Código fuente principal
├── README.md                  ← Esta documentación
├── assets/
│   ├── icon.png               ← Ícono de la aplicación (Linux)
│   └── icon.ico               ← Ícono de la aplicación (Windows)
└── installers/
    ├── shared/
    │   ├── videoflex.spec     ← Configuración PyInstaller
    │   └── version_info.txt   ← Metadatos versión Windows
    ├── windows/
    │   ├── build_windows.bat  ← Build script para Windows
    │   └── videoflex_installer.iss  ← Script Inno Setup
    ├── arch/
    │   ├── PKGBUILD           ← Receta de paquete Arch
    │   └── build_arch.sh      ← Build script Arch
    ├── debian/
    │   └── build_debian.sh    ← Build script Debian/Ubuntu
    └── rpm/
        ├── videoflex.spec     ← Spec RPM
        └── build_rpm.sh       ← Build script RPM/Fedora
```

---

## 🔧 Notas técnicas

- La UI está construida con **Flet 0.21+** (wrapper Python de Flutter)
- Las descargas de video corren en **threads separados** para no bloquear la UI
- El arranque usa `_prefetch_slow_data()` en thread para diferir el import de `yt-dlp` y evitar el freeze inicial en Windows
- La configuración se persiste en JSON en el directorio home del usuario
- El monitor del portapapeles usa un timeout de 0.8s en Windows para evitar bloqueos

---

## 🐛 Problemas conocidos

- En Windows, el splash screen puede verse brevemente antes de que la ventana se minimice durante la inicialización (comportamiento de Flutter/Win32)
- `BoxShadow` de Flet no renderiza correctamente en algunas versiones de GTK en Linux

---

## 📄 Licencia

Todos los derechos reservados. © PFE Computación 2025-2026.  
Desarrollado por **Pablo F. Espinosa**.

Este software es de uso privado. No está permitida su distribución, modificación o uso comercial sin autorización expresa del autor.

---

<div align="center">

Hecho con ❤️ por **PFE Computación**

</div>
