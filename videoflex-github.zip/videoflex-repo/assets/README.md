# Coloca aquí icon.png (Linux) e icon.ico (Windows)
