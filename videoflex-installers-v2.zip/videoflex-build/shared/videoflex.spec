# -*- mode: python ; coding: utf-8 -*-
# PyInstaller spec file para VideoFlex v1.5.0
# Uso: pyinstaller videoflex.spec

import sys
import os
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

block_cipher = None

flet_datas = collect_data_files('flet', include_py_files=False)

# Incluir carpeta assets/ si existe (íconos, recursos)
extra_datas = []
if os.path.exists('assets'):
    extra_datas.append(('assets', 'assets'))

a = Analysis(
    ['videoflex_v3-1.py'],
    pathex=['.'],
    binaries=[],
    datas=flet_datas + extra_datas,
    hiddenimports=[
        'flet', 'flet.controls', 'flet.messaging',
        'flet_core', 'flet_runtime',
        'requests', 'requests.adapters', 'requests.packages',
        'urllib3', 'urllib3.util', 'urllib3.util.retry',
        'certifi', 'charset_normalizer', 'idna',
        'pyperclip',
        'tkinter', 'tkinter.filedialog', '_tkinter',
        'yt_dlp', 'yt_dlp.extractor', 'yt_dlp.downloader', 'yt_dlp.postprocessor',
        'psutil',
        'json', 'pathlib', 'threading', 'asyncio',
        'dataclasses', 'enum', 'concurrent.futures', 'csv', 'collections',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'matplotlib', 'numpy', 'PIL', 'scipy',
        'pandas', 'IPython', 'jupyter',
        'PyQt5', 'PyQt6', 'PySide2', 'PySide6', 'wx',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='VideoFlex',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    # Windows: descomenta si tienes assets/icon.ico
    # icon='assets/icon.ico',
    # version='version_info.txt',
)
