#!/usr/bin/env bash
# =============================================================
#  VideoFlex - Build Script para Arch Linux / CachyOS / Manjaro
#  Genera: videoflex-1.5.0-1-x86_64.pkg.tar.zst
#  Uso:    chmod +x build_arch.sh && ./build_arch.sh
# =============================================================
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; BOLD='\033[1m'; NC='\033[0m'
info()  { echo -e "${BLUE}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

echo -e "${BOLD}"
echo "  ╔══════════════════════════════════════════════════╗"
echo "  ║  VideoFlex — Build para Arch / CachyOS / Manjaro ║"
echo "  ║  Genera: videoflex-1.5.0-1-x86_64.pkg.tar.zst   ║"
echo "  ╚══════════════════════════════════════════════════╝"
echo -e "${NC}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"

# ── Verificar dependencias ─────────────────────────────────────
info "Verificando dependencias del sistema..."
for cmd in python makepkg; do
    command -v "$cmd" &>/dev/null || error "'$cmd' no encontrado."
done

if ! pacman -Qi base-devel &>/dev/null 2>&1; then
    warn "base-devel no instalado. Instalando..."
    sudo pacman -S --needed --noconfirm base-devel \
        || error "No se pudo instalar base-devel"
fi
ok "Dependencias del sistema OK"

# ── Copiar fuentes al directorio arch/ ────────────────────────
info "Preparando archivos fuente..."

# Script Python (v3-1 preferido, v3 como fallback)
PY_SRC=""
for CANDIDATE in "videoflex_v3-1.py" "videoflex_v3.py"; do
    for SEARCH in "$SCRIPT_DIR" "$ROOT_DIR" "$(pwd)"; do
        if [ -f "$SEARCH/$CANDIDATE" ]; then
            PY_SRC="$SEARCH/$CANDIDATE"; break 2
        fi
    done
done
[ -z "$PY_SRC" ] && error "No se encontró videoflex_v3-1.py ni videoflex_v3.py"
cp "$PY_SRC" "$SCRIPT_DIR/videoflex_v3-1.py"
ok "$(basename "$PY_SRC") copiado"

# Spec y version_info
cp "$ROOT_DIR/shared/videoflex.spec"   "$SCRIPT_DIR/"
cp "$ROOT_DIR/shared/version_info.txt" "$SCRIPT_DIR/"
ok "Archivos shared/ copiados"

# Carpeta assets/
if [ -d "$ROOT_DIR/assets" ]; then
    cp -r "$ROOT_DIR/assets" "$SCRIPT_DIR/"
    ok "assets/ copiado"
elif [ -d "$SCRIPT_DIR/assets" ]; then
    ok "assets/ ya presente en arch/"
else
    warn "No se encontró assets/ — el paquete usará ícono genérico"
fi

# ── Ejecutar makepkg ───────────────────────────────────────────
info "Ejecutando makepkg..."
cd "$SCRIPT_DIR"
makepkg -s --clean --noconfirm 2>&1

# ── Verificar resultado ────────────────────────────────────────
PKG_FILE=$(ls videoflex-*.pkg.tar.zst 2>/dev/null | head -1 || true)
[ -z "$PKG_FILE" ] && error "No se generó el paquete .pkg.tar.zst"
ok "Paquete generado: ${PKG_FILE}"

echo ""
echo -e "${BOLD}${GREEN}  ══════════════════════════════════════════════════${NC}"
echo -e "${BOLD}${GREEN}  BUILD COMPLETADO: ${PKG_FILE}${NC}"
echo -e "${BOLD}${GREEN}  ══════════════════════════════════════════════════${NC}"
echo ""
echo "  Para instalar:"
echo "    sudo pacman -U ${PKG_FILE}"
echo ""
echo "  Dependencias recomendadas:"
echo "    sudo pacman -S ffmpeg qbittorrent vlc"
echo ""
echo "  Para desinstalar:"
echo "    sudo pacman -R videoflex"
