# 📦 VideoFlex v1.5.0 — Guía de Generación de Instaladores

> Desarrollado por **Pablo F. Espinosa · PFE Computación** © 2025-2026

---

## 📁 Estructura del paquete

```
videoflex-installers/
├── shared/
│   ├── videoflex.spec          ← Configuración PyInstaller (todas las plataformas)
│   └── version_info.txt        ← Metadatos del .exe (solo Windows)
├── assets/                     ← TU ÍCONO VA AQUÍ
│   ├── icon.png                ← Ícono para Linux (256×256px recomendado)
│   └── icon.ico                ← Ícono para Windows (multi-resolución)
├── arch/
│   ├── PKGBUILD                ← Receta de paquete Arch / CachyOS / Manjaro
│   └── build_arch.sh           ← Script de build automatizado
├── debian/
│   └── build_debian.sh         ← Script de build para Debian / Ubuntu / Mint
└── rpm/
    ├── videoflex.spec          ← Spec RPM (Fedora / RHEL / openSUSE)
    └── build_rpm.sh            ← Script de build automatizado
```

Coloca `videoflex_v3-1.py` en la **raíz** del paquete (al mismo nivel que las carpetas).

---

## 🔷 Arch Linux / CachyOS / Manjaro → `.pkg.tar.zst`

### Requisitos
```bash
sudo pacman -S --needed base-devel python python-pip
```

### Build
```bash
cd arch/
chmod +x build_arch.sh
./build_arch.sh
```

### Instalar
```bash
sudo pacman -U videoflex-1.5.0-1-x86_64.pkg.tar.zst
```

### Desinstalar
```bash
sudo pacman -R videoflex
```

---

## 🟠 Debian / Ubuntu / Linux Mint → `.deb`

### Requisitos
```bash
sudo apt install python3 python3-pip python3-venv dpkg-dev
```

### Build
```bash
cd debian/
chmod +x build_debian.sh
./build_debian.sh
```

### Instalar
```bash
sudo dpkg -i videoflex_1.5.0_amd64.deb
sudo apt install -f      # Resolver dependencias si es necesario
```

### Desinstalar
```bash
sudo apt remove videoflex
sudo apt purge videoflex   # Elimina también configuración
```

---

## 🔴 Fedora / RHEL / openSUSE → `.rpm`

Detección automática de distro: usa `dnf` (Fedora/RHEL/Rocky/AlmaLinux) o `zypper` (openSUSE).

### Requisitos

**Fedora / RHEL:**
```bash
sudo dnf install python3 python3-pip rpm-build rpmdevtools
```

**openSUSE:**
```bash
sudo zypper install python3 python3-pip rpm-build rpmdevtools
```

### Build
```bash
cd rpm/
chmod +x build_rpm.sh
./build_rpm.sh
```

### Instalar

**Fedora / RHEL:**
```bash
sudo dnf install ./videoflex-1.5.0-1.fc*.x86_64.rpm
```

**openSUSE:**
```bash
sudo zypper install ./videoflex-1.5.0-1.*.x86_64.rpm
```

### Desinstalar

**Fedora / RHEL:**
```bash
sudo dnf remove videoflex
```

**openSUSE:**
```bash
sudo zypper remove videoflex
```

---

## 🖼️ Ícono personalizado

Coloca los íconos en `assets/` (al mismo nivel que las carpetas `arch/`, `debian/`, `rpm/`):

```
assets/
├── icon.png   ← Linux (PNG, 256×256px mínimo)
└── icon.ico   ← Windows (ICO multi-resolución: 16, 32, 48, 256px)
```

Los scripts detectan automáticamente los íconos y los instalan en:

| Plataforma | Ruta del ícono |
|---|---|
| Arch `.pkg` | `/usr/share/icons/hicolor/256x256/apps/videoflex.png` |
| Debian `.deb` | `/usr/share/icons/hicolor/256x256/apps/videoflex.png` |
| RPM | `/usr/share/icons/hicolor/256x256/apps/videoflex.png` |

Si no hay ícono, todos los instaladores usan el ícono genérico del sistema sin fallar.

---

## ⚙️ Cómo funciona el proceso

```
videoflex_v3-1.py
      │
      ▼  PyInstaller (venv aislado)
  VideoFlex          ← ejecutable standalone
      │
      ├──▶ [Arch]    makepkg      →  videoflex-1.5.0-1-x86_64.pkg.tar.zst
      ├──▶ [Debian]  dpkg-deb     →  videoflex_1.5.0_amd64.deb
      └──▶ [RPM]     rpmbuild     →  videoflex-1.5.0-1.fc*.x86_64.rpm
```

---

## 📋 Dependencias externas (no incluidas)

| Herramienta | Para qué | Instalación |
|---|---|---|
| **ffmpeg** | Convertir/mezclar video+audio | `pacman -S ffmpeg` / `apt install ffmpeg` / `dnf install ffmpeg` |
| **yt-dlp** | Motor de descarga de videos | Incluido automáticamente vía pip en el venv de build |
| **qBittorrent** | Gestión de Torrents | https://www.qbittorrent.org |
| **vlc** | Reproductor multimedia | `pacman -S vlc` / `apt install vlc` / `dnf install vlc` |

---

## 🔧 Cambiar versión

Edita la variable `APP_VERSION` en cada script de build:

| Script | Variable |
|---|---|
| `arch/PKGBUILD` | `pkgver=1.5.0` |
| `debian/build_debian.sh` | `APP_VERSION="1.5.0"` |
| `rpm/build_rpm.sh` | `APP_VERSION="1.5.0"` |
| `rpm/videoflex.spec` | `Version: 1.5.0` |

---

## ❓ Solución de problemas

| Plataforma | Error | Solución |
|---|---|---|
| Arch | `ERROR: 'makepkg' must not be run as root` | Ejecuta como usuario normal, no con sudo |
| Arch | `ERROR: Cannot find the fakeroot binary` | `sudo pacman -S fakeroot` |
| Debian | `Depends: libgtk-3-0 but it is not installable` | `sudo apt update && sudo apt install libgtk-3-0` |
| Debian | La app no aparece en el menú | `sudo update-desktop-database` |
| RPM | `rpmdev-setuptree: command not found` | `sudo dnf install rpmdevtools` |
| RPM | `error: Failed build dependencies` | El spec lista las dependencias faltantes, instálalas con dnf/zypper |
| Todos | `ModuleNotFoundError: flet` | Verifica que el venv_build se creó correctamente |
| Todos | El ejecutable no arranca | Verifica que las dependencias GTK están instaladas |
