#!/usr/bin/env bash
# =============================================================
#  VideoFlex - Build Script para Fedora / RHEL / openSUSE
#  Genera: videoflex-1.5.0-1.fc*.x86_64.rpm
#          videoflex-1.5.0-1.el*.x86_64.rpm  (RHEL/CentOS)
#          videoflex-1.5.0-1.*.x86_64.rpm    (openSUSE)
#
#  Uso:    chmod +x build_rpm.sh && ./build_rpm.sh
#
#  Detección automática de distro:
#    - Fedora:   usa dnf
#    - RHEL/CentOS/Rocky/AlmaLinux: usa dnf o yum
#    - openSUSE: usa zypper
# =============================================================
set -euo pipefail

APP_NAME="videoflex"
APP_VERSION="1.5.0"
APP_RELEASE="1"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; BOLD='\033[1m'; NC='\033[0m'
info()  { echo -e "${BLUE}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

echo -e "${BOLD}"
echo "  ╔══════════════════════════════════════════════════╗"
echo "  ║  VideoFlex — Build para Fedora / RHEL / openSUSE ║"
echo "  ║  Genera: videoflex-${APP_VERSION}-${APP_RELEASE}.*.x86_64.rpm   ║"
echo "  ╚══════════════════════════════════════════════════╝"
echo -e "${NC}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"

# ── Detectar gestor de paquetes ────────────────────────────────
info "Detectando distribución..."
PKG_MGR=""
DISTRO=""
if command -v dnf &>/dev/null; then
    PKG_MGR="dnf"; DISTRO="fedora_rhel"
    ok "dnf detectado (Fedora / RHEL / Rocky / AlmaLinux)"
elif command -v yum &>/dev/null; then
    PKG_MGR="yum"; DISTRO="fedora_rhel"
    ok "yum detectado (RHEL / CentOS)"
elif command -v zypper &>/dev/null; then
    PKG_MGR="zypper"; DISTRO="opensuse"
    ok "zypper detectado (openSUSE)"
else
    error "No se detectó dnf, yum ni zypper. ¿Es esta una distro basada en RPM?"
fi

# ── Instalar dependencias de build ────────────────────────────
info "Instalando dependencias de build..."
if [ "$DISTRO" = "fedora_rhel" ]; then
    sudo $PKG_MGR install -y \
        python3 python3-pip python3-virtualenv \
        rpm-build rpmdevtools \
        xclip gtk3 \
        || error "No se pudieron instalar las dependencias"
elif [ "$DISTRO" = "opensuse" ]; then
    sudo zypper install -y \
        python3 python3-pip python3-virtualenv \
        rpm-build rpmdevtools \
        xclip gtk3 \
        || error "No se pudieron instalar las dependencias"
fi
ok "Dependencias de build instaladas"

# ── Verificar Python ───────────────────────────────────────────
PYTHON_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}{sys.version_info.minor}')")
[ "$PYTHON_VERSION" -lt 310 ] && error "Se requiere Python 3.10 o superior."
ok "Python $(python3 --version) detectado"

# ── Localizar script Python ────────────────────────────────────
info "Localizando script fuente..."
PY_SRC=""
for CANDIDATE in "videoflex_v3-1.py" "videoflex_v3.py"; do
    for SEARCH in "$SCRIPT_DIR" "$ROOT_DIR" "$(pwd)"; do
        if [ -f "$SEARCH/$CANDIDATE" ]; then
            PY_SRC="$SEARCH/$CANDIDATE"; break 2
        fi
    done
done
[ -z "$PY_SRC" ] && error "No se encontró videoflex_v3-1.py ni videoflex_v3.py"
ok "Fuente: $PY_SRC"

# ── Localizar ícono desde assets/ ─────────────────────────────
ICON_SRC=""
for SEARCH in "$ROOT_DIR/assets" "$SCRIPT_DIR/assets" "$ROOT_DIR" "$SCRIPT_DIR"; do
    for NAME in "icon.png" "icon.ico"; do
        [ -f "$SEARCH/$NAME" ] && { ICON_SRC="$SEARCH/$NAME"; break 2; }
    done
done
if [ -n "$ICON_SRC" ]; then
    ok "Ícono encontrado: $ICON_SRC"
else
    warn "No se encontró assets/icon.png — se usará ícono genérico"
fi

# ── Configurar árbol rpmbuild ──────────────────────────────────
info "Configurando árbol rpmbuild..."
RPMBUILD_DIR="$HOME/rpmbuild"
rpmdev-setuptree
ok "Árbol rpmbuild listo en $RPMBUILD_DIR"

# ── Crear entorno virtual de build ────────────────────────────
info "Creando entorno virtual de build..."
VENV_DIR="$SCRIPT_DIR/venv_build_rpm"
[ -d "$VENV_DIR" ] && rm -rf "$VENV_DIR"
python3 -m venv "$VENV_DIR"
source "$VENV_DIR/bin/activate"

# ── Instalar dependencias Python ──────────────────────────────
info "Instalando dependencias Python..."
pip install --upgrade pip --quiet
pip install "flet>=0.21.0"      --quiet
pip install "pyinstaller>=6.0"  --quiet
pip install requests             --quiet
pip install pyperclip            --quiet
pip install psutil               --quiet
pip install yt-dlp               --quiet
ok "Dependencias Python instaladas"

# ── Compilar con PyInstaller ───────────────────────────────────
info "Compilando con PyInstaller..."
BUILD_WORK="$SCRIPT_DIR/build_rpm_tmp"
mkdir -p "$BUILD_WORK"
cd "$BUILD_WORK"

cp "$PY_SRC" ./videoflex_v3-1.py
cp "$ROOT_DIR/shared/videoflex.spec" ./videoflex_pyinstaller.spec
cp "$ROOT_DIR/shared/version_info.txt" .

# Usar el nombre correcto del spec de PyInstaller
mv videoflex_pyinstaller.spec videoflex.spec
sed -i "s/version='version_info.txt',/# version='version_info.txt',  # Solo Windows/" videoflex.spec

# Copiar assets/
if [ -n "$ICON_SRC" ]; then
    ASSETS_SRC_DIR="$(dirname "$ICON_SRC")"
    [ -d "$ASSETS_SRC_DIR" ] && cp -r "$ASSETS_SRC_DIR" ./assets
fi

pyinstaller videoflex.spec --clean --noconfirm \
    --distpath ./dist \
    --workpath ./build

[ -f "dist/VideoFlex" ] || error "PyInstaller no generó el ejecutable"
ok "Ejecutable generado: dist/VideoFlex"
deactivate

# ── Preparar tarball fuente para rpmbuild ─────────────────────
info "Preparando fuentes para rpmbuild..."
TAR_DIR="${APP_NAME}-${APP_VERSION}"
TAR_STAGE="$SCRIPT_DIR/tar_stage/$TAR_DIR"
mkdir -p "$TAR_STAGE/assets"

cp "$BUILD_WORK/dist/VideoFlex" "$TAR_STAGE/"

# Incluir assets/
if [ -d "$BUILD_WORK/assets" ]; then
    cp -r "$BUILD_WORK/assets/"* "$TAR_STAGE/assets/" 2>/dev/null || true
fi

# Crear tarball
cd "$SCRIPT_DIR/tar_stage"
tar czf "$RPMBUILD_DIR/SOURCES/${APP_NAME}-${APP_VERSION}.tar.gz" "$TAR_DIR"
ok "Tarball creado en SOURCES/"

# ── Copiar spec RPM ────────────────────────────────────────────
cp "$SCRIPT_DIR/videoflex.spec" "$RPMBUILD_DIR/SPECS/"

# Si no hay icon.png, ajustar el spec para no incluir esa línea en %files
if [ -z "$ICON_SRC" ] || [ ! -f "$BUILD_WORK/assets/icon.png" ]; then
    sed -i 's|/usr/share/icons/hicolor/256x256/apps/videoflex.png||' \
        "$RPMBUILD_DIR/SPECS/videoflex.spec"
    warn "Ícono no disponible — línea de ícono eliminada del spec"
fi

# ── Construir el RPM ───────────────────────────────────────────
info "Construyendo paquete RPM..."
cd "$RPMBUILD_DIR/SPECS"
rpmbuild -bb videoflex.spec \
    --define "_topdir $RPMBUILD_DIR" \
    2>&1

# ── Localizar y copiar RPM generado ───────────────────────────
RPM_FILE=$(find "$RPMBUILD_DIR/RPMS/x86_64/" -name "${APP_NAME}-*.rpm" | head -1 || true)
[ -z "$RPM_FILE" ] && error "No se generó el paquete RPM"

cp "$RPM_FILE" "$SCRIPT_DIR/"
RPM_BASENAME="$(basename "$RPM_FILE")"
ok "Paquete copiado: $SCRIPT_DIR/$RPM_BASENAME"

# ── Verificar el RPM ───────────────────────────────────────────
info "Verificando paquete RPM..."
rpm -qip "$SCRIPT_DIR/$RPM_BASENAME"

# ── Limpieza ───────────────────────────────────────────────────
rm -rf "$VENV_DIR" "$BUILD_WORK" "$SCRIPT_DIR/tar_stage"

echo ""
echo -e "${BOLD}${GREEN}  ══════════════════════════════════════════════════${NC}"
echo -e "${BOLD}${GREEN}  BUILD COMPLETADO: ${RPM_BASENAME}${NC}"
echo -e "${BOLD}${GREEN}  ══════════════════════════════════════════════════${NC}"
echo ""
echo "  Para instalar:"
if [ "$DISTRO" = "opensuse" ]; then
    echo "    sudo zypper install ./${RPM_BASENAME}"
else
    echo "    sudo dnf install ./${RPM_BASENAME}"
    echo "    # o: sudo rpm -i ${RPM_BASENAME}"
fi
echo ""
echo "  Dependencias recomendadas:"
if [ "$DISTRO" = "opensuse" ]; then
    echo "    sudo zypper install ffmpeg qbittorrent vlc"
else
    echo "    sudo dnf install ffmpeg qbittorrent vlc"
fi
echo ""
echo "  Para desinstalar:"
if [ "$DISTRO" = "opensuse" ]; then
    echo "    sudo zypper remove videoflex"
else
    echo "    sudo dnf remove videoflex"
fi
