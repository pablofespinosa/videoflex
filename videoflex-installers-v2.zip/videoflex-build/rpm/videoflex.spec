Name:           videoflex
Version:        1.5.0
Release:        1%{?dist}
Summary:        Descargador Universal de Videos y Torrents

License:        Proprietary
URL:            https://github.com/pfe-computacion/videoflex
# El binario se compila localmente con build_rpm.sh antes de llamar a rpmbuild

# Sin fuentes remotas — el build script prepara todo localmente
Source0:        %{name}-%{version}.tar.gz

BuildArch:      x86_64
# Sin BuildRequires de compiladores porque el binario ya viene precompilado
# por PyInstaller desde build_rpm.sh

Requires:       gtk3
Requires:       glib2
Requires:       cairo
Requires:       pango
Requires:       gdk-pixbuf2
Requires:       libX11
Requires:       xclip

Recommends:     ffmpeg
Recommends:     qbittorrent
Recommends:     vlc

Provides:       %{name} = %{version}
Conflicts:      %{name}-git

%description
VideoFlex es una aplicación multiplataforma para descargar videos
de YouTube, TikTok, Instagram, Facebook y otros sitios, además de
gestionar descargas de Torrents a través de qBittorrent.

Características:
 - Descarga de videos en múltiples calidades (hasta 4K)
 - Sistema anti-bloqueo con soporte de cookies
 - Gestión de Torrents integrada vía qBittorrent WebUI
 - Historial y estadísticas de descarga
 - Interfaz gráfica moderna con efectos visuales

%prep
%setup -q

%build
# El binario ya fue compilado por build_rpm.sh con PyInstaller
# No hay pasos de compilación adicionales aquí

%install
rm -rf %{buildroot}

# Directorios
install -dm755 %{buildroot}/opt/videoflex
install -dm755 %{buildroot}/opt/videoflex/assets
install -dm755 %{buildroot}/usr/local/bin
install -dm755 %{buildroot}/usr/share/applications
install -dm755 %{buildroot}/usr/share/icons/hicolor/256x256/apps
install -dm755 %{buildroot}/usr/share/licenses/%{name}

# Ejecutable principal
install -Dm755 VideoFlex %{buildroot}/opt/videoflex/videoflex

# Assets (ícono y recursos)
if [ -d assets ]; then
    cp -r assets/* %{buildroot}/opt/videoflex/assets/
fi

# Ícono en el sistema
if [ -f assets/icon.png ]; then
    install -Dm644 assets/icon.png \
        %{buildroot}/usr/share/icons/hicolor/256x256/apps/videoflex.png
fi

# Wrapper en PATH
cat > %{buildroot}/usr/local/bin/videoflex << 'EOF'
#!/bin/bash
exec /opt/videoflex/videoflex "$@"
EOF
chmod 755 %{buildroot}/usr/local/bin/videoflex

# Entrada .desktop
cat > %{buildroot}/usr/share/applications/videoflex.desktop << 'EOF'
[Desktop Entry]
Version=1.1
Type=Application
Name=VideoFlex
GenericName=Descargador de Videos y Torrents
Comment=Descarga videos de YouTube, TikTok, Instagram y gestiona Torrents
Exec=/opt/videoflex/videoflex %U
Icon=videoflex
Terminal=false
StartupNotify=true
StartupWMClass=VideoFlex
Categories=Network;FileTransfer;Video;AudioVideo;
Keywords=video;youtube;torrent;download;descargar;tiktok;instagram;
MimeType=x-scheme-handler/magnet;
EOF

# Licencia
cat > %{buildroot}/usr/share/licenses/%{name}/LICENSE << 'EOF'
VideoFlex — Descargador Universal de Videos y Torrents
Copyright © PFE Computación 2025-2026
Desarrollado por Pablo F. Espinosa
Todos los derechos reservados.
EOF

%files
/opt/videoflex/
/usr/local/bin/videoflex
/usr/share/applications/videoflex.desktop
/usr/share/icons/hicolor/256x256/apps/videoflex.png
/usr/share/licenses/%{name}/LICENSE

%post
# Actualizar caché de íconos y .desktop
gtk-update-icon-cache -f -t /usr/share/icons/hicolor &>/dev/null || true
update-desktop-database /usr/share/applications &>/dev/null || true
xdg-mime default videoflex.desktop x-scheme-handler/magnet &>/dev/null || true
echo ""
echo "VideoFlex instalado. Dependencias recomendadas:"
echo "  Fedora:   sudo dnf install ffmpeg qbittorrent vlc"
echo "  openSUSE: sudo zypper install ffmpeg qbittorrent vlc"

%preun
xdg-mime uninstall /usr/share/applications/videoflex.desktop &>/dev/null || true

%postun
gtk-update-icon-cache -f -t /usr/share/icons/hicolor &>/dev/null || true
update-desktop-database /usr/share/applications &>/dev/null || true

%changelog
* Sun Mar 15 2026 Pablo F. Espinosa <contacto@pfe-computacion.com> - 1.5.0-1
- Versión 1.5.0 Enhanced
- Efectos hover en botones del dashboard
- Soporte de ícono personalizado desde assets/
- Mejoras en logging y gestión de descargas
