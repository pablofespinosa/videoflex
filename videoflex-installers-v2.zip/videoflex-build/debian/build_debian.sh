#!/usr/bin/env bash
# =============================================================
#  VideoFlex - Build Script para Debian / Ubuntu / Linux Mint
#  Genera: videoflex_1.5.0_amd64.deb
#  Uso:    chmod +x build_debian.sh && ./build_debian.sh
# =============================================================
set -euo pipefail

APP_NAME="videoflex"
APP_VERSION="1.5.0"
APP_ARCH="amd64"
PKG_NAME="${APP_NAME}_${APP_VERSION}_${APP_ARCH}"
INSTALL_DIR="/opt/videoflex"
DESKTOP_DIR="/usr/share/applications"
ICON_DIR_SYS="/usr/share/icons/hicolor/256x256/apps"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; BOLD='\033[1m'; NC='\033[0m'
info()  { echo -e "${BLUE}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

echo -e "${BOLD}"
echo "  ╔══════════════════════════════════════════════════╗"
echo "  ║  VideoFlex — Build para Debian / Ubuntu / Mint   ║"
echo "  ║  Genera: ${PKG_NAME}.deb                  ║"
echo "  ╚══════════════════════════════════════════════════╝"
echo -e "${NC}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname "$SCRIPT_DIR")"

# ── Verificar dependencias del sistema ────────────────────────
info "Verificando dependencias del sistema..."
for cmd in python3 pip3 dpkg-deb; do
    command -v "$cmd" &>/dev/null \
        || error "$cmd no encontrado. Ejecuta: sudo apt install python3 python3-pip dpkg"
done

PYTHON_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}{sys.version_info.minor}')")
[ "$PYTHON_VERSION" -lt 310 ] && error "Se requiere Python 3.10 o superior."
ok "Python $(python3 --version) detectado"

# ── Localizar script Python ────────────────────────────────────
info "Localizando script fuente..."
PY_SRC=""
for CANDIDATE in "videoflex_v3-1.py" "videoflex_v3.py"; do
    for SEARCH in "$SCRIPT_DIR" "$ROOT_DIR" "$(pwd)"; do
        if [ -f "$SEARCH/$CANDIDATE" ]; then
            PY_SRC="$SEARCH/$CANDIDATE"; break 2
        fi
    done
done
[ -z "$PY_SRC" ] && error "No se encontró videoflex_v3-1.py ni videoflex_v3.py"
ok "Fuente: $PY_SRC"

# ── Localizar ícono desde assets/ ─────────────────────────────
ICON_SRC=""
for SEARCH in "$ROOT_DIR/assets" "$SCRIPT_DIR/assets" "$ROOT_DIR" "$SCRIPT_DIR"; do
    for NAME in "icon.png" "icon.ico"; do
        [ -f "$SEARCH/$NAME" ] && { ICON_SRC="$SEARCH/$NAME"; break 2; }
    done
done
if [ -n "$ICON_SRC" ]; then
    ok "Ícono encontrado: $ICON_SRC"
else
    warn "No se encontró assets/icon.png — se usará ícono genérico"
fi

# ── Crear entorno virtual de build ────────────────────────────
info "Creando entorno virtual de build..."
VENV_DIR="$SCRIPT_DIR/venv_build_deb"
[ -d "$VENV_DIR" ] && rm -rf "$VENV_DIR"
python3 -m venv "$VENV_DIR"
source "$VENV_DIR/bin/activate"

# ── Instalar dependencias ──────────────────────────────────────
info "Instalando dependencias Python..."
pip install --upgrade pip --quiet
pip install "flet>=0.21.0"      --quiet
pip install "pyinstaller>=6.0"  --quiet
pip install requests             --quiet
pip install pyperclip            --quiet
pip install psutil               --quiet
pip install yt-dlp               --quiet
ok "Dependencias instaladas"

# ── Compilar con PyInstaller ───────────────────────────────────
info "Compilando con PyInstaller..."
BUILD_DIR="$SCRIPT_DIR/build_deb_tmp"
mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

cp "$PY_SRC" ./videoflex_v3-1.py
cp "$ROOT_DIR/shared/videoflex.spec" .
cp "$ROOT_DIR/shared/version_info.txt" .

# Parchear spec para Linux
sed -i "s/version='version_info.txt',/# version='version_info.txt',  # Solo Windows/" videoflex.spec

# Copiar assets/ si existe
if [ -n "$ICON_SRC" ]; then
    ASSETS_DIR="$(dirname "$ICON_SRC")"
    [ -d "$ASSETS_DIR" ] && cp -r "$ASSETS_DIR" ./assets
fi

pyinstaller videoflex.spec --clean --noconfirm \
    --distpath ./dist \
    --workpath ./build

[ -f "dist/VideoFlex" ] || error "PyInstaller no generó el ejecutable"
ok "Ejecutable generado: dist/VideoFlex"

# ── Crear estructura del paquete .deb ─────────────────────────
info "Construyendo estructura del paquete .deb..."
DEB_ROOT="$SCRIPT_DIR/${PKG_NAME}"
[ -d "$DEB_ROOT" ] && rm -rf "$DEB_ROOT"

mkdir -p "${DEB_ROOT}/DEBIAN"
mkdir -p "${DEB_ROOT}${INSTALL_DIR}/assets"
mkdir -p "${DEB_ROOT}${DESKTOP_DIR}"
mkdir -p "${DEB_ROOT}/usr/local/bin"
mkdir -p "${DEB_ROOT}${ICON_DIR_SYS}"

# Ejecutable
cp dist/VideoFlex "${DEB_ROOT}${INSTALL_DIR}/videoflex"
chmod 755 "${DEB_ROOT}${INSTALL_DIR}/videoflex"

# Assets
if [ -d "./assets" ]; then
    cp -r ./assets/* "${DEB_ROOT}${INSTALL_DIR}/assets/"
    ok "assets/ incluidos en el paquete"
fi

# Tamaño instalado
INSTALLED_SIZE=$(du -sk "${DEB_ROOT}${INSTALL_DIR}" | cut -f1)

# Ícono en el sistema de íconos
ICON_LINE="Icon=video-display"
if [ -f "./assets/icon.png" ]; then
    cp ./assets/icon.png "${DEB_ROOT}${ICON_DIR_SYS}/videoflex.png"
    ICON_LINE="Icon=videoflex"
    ok "Ícono instalado en $ICON_DIR_SYS"
elif [ -f "./assets/icon.ico" ]; then
    cp ./assets/icon.ico "${DEB_ROOT}${INSTALL_DIR}/assets/icon.ico"
    ICON_LINE="Icon=${INSTALL_DIR}/assets/icon.ico"
fi

# Symlink en /usr/local/bin
cat > "${DEB_ROOT}/usr/local/bin/videoflex" << 'EOF'
#!/bin/bash
exec /opt/videoflex/videoflex "$@"
EOF
chmod 755 "${DEB_ROOT}/usr/local/bin/videoflex"

# Entrada .desktop
cat > "${DEB_ROOT}${DESKTOP_DIR}/videoflex.desktop" << DESK_EOF
[Desktop Entry]
Version=1.1
Type=Application
Name=VideoFlex
GenericName=Descargador de Videos y Torrents
Comment=Descarga videos de YouTube, TikTok, Instagram y gestiona Torrents
Exec=/opt/videoflex/videoflex %U
${ICON_LINE}
Terminal=false
StartupNotify=true
StartupWMClass=VideoFlex
Categories=Network;FileTransfer;Video;AudioVideo;
Keywords=video;youtube;torrent;download;descargar;tiktok;instagram;
MimeType=x-scheme-handler/magnet;
DESK_EOF

# Control del paquete
cat > "${DEB_ROOT}/DEBIAN/control" << CTRL_EOF
Package: ${APP_NAME}
Version: ${APP_VERSION}
Section: net
Priority: optional
Architecture: ${APP_ARCH}
Installed-Size: ${INSTALLED_SIZE}
Depends: libgtk-3-0, libglib2.0-0, libgdk-pixbuf-2.0-0, libpango-1.0-0, libcairo2, libx11-6, libc6 (>= 2.17), xclip
Recommends: ffmpeg, qbittorrent, vlc
Maintainer: Pablo F. Espinosa <contacto@pfe-computacion.com>
Homepage: https://github.com/pfe-computacion/videoflex
Description: Descargador Universal de Videos y Torrents
 VideoFlex es una aplicación multiplataforma para descargar videos
 de YouTube, TikTok, Instagram, Facebook y otros sitios, además de
 gestionar descargas de Torrents a través de qBittorrent.
 .
 Características:
  - Descarga de videos en múltiples calidades (hasta 4K)
  - Sistema anti-bloqueo con soporte de cookies
  - Gestión de Torrents integrada vía qBittorrent WebUI
  - Historial y estadísticas de descarga
  - Interfaz gráfica moderna con efectos visuales
CTRL_EOF

# Post-instalación
cat > "${DEB_ROOT}/DEBIAN/postinst" << 'POSTINST_EOF'
#!/bin/bash
set -e
command -v update-desktop-database &>/dev/null \
    && update-desktop-database /usr/share/applications || true
command -v gtk-update-icon-cache &>/dev/null \
    && gtk-update-icon-cache -f -t /usr/share/icons/hicolor || true
command -v xdg-mime &>/dev/null \
    && xdg-mime default videoflex.desktop x-scheme-handler/magnet || true
echo ""
echo "VideoFlex instalado. Dependencias recomendadas:"
echo "  sudo apt install ffmpeg qbittorrent vlc"
exit 0
POSTINST_EOF
chmod 755 "${DEB_ROOT}/DEBIAN/postinst"

# Pre-desinstalación
cat > "${DEB_ROOT}/DEBIAN/prerm" << 'PRERM_EOF'
#!/bin/bash
set -e
command -v xdg-mime &>/dev/null \
    && xdg-mime uninstall /usr/share/applications/videoflex.desktop 2>/dev/null || true
exit 0
PRERM_EOF
chmod 755 "${DEB_ROOT}/DEBIAN/prerm"

# ── Construir el .deb ──────────────────────────────────────────
info "Generando paquete .deb..."
cd "$SCRIPT_DIR"
dpkg-deb --build --root-owner-group "${DEB_ROOT}"

[ -f "${PKG_NAME}.deb" ] || error "No se generó el paquete .deb"
ok "Paquete generado: ${PKG_NAME}.deb"

dpkg-deb --info "${PKG_NAME}.deb"

# ── Limpieza ───────────────────────────────────────────────────
deactivate
rm -rf "$VENV_DIR" "$DEB_ROOT" "$BUILD_DIR"

echo ""
echo -e "${BOLD}${GREEN}  ══════════════════════════════════════════════════${NC}"
echo -e "${BOLD}${GREEN}  BUILD COMPLETADO: ${PKG_NAME}.deb${NC}"
echo -e "${BOLD}${GREEN}  ══════════════════════════════════════════════════${NC}"
echo ""
echo "  Para instalar:"
echo "    sudo dpkg -i ${PKG_NAME}.deb"
echo "    sudo apt install -f      # Resolver dependencias si es necesario"
echo ""
echo "  Dependencias recomendadas:"
echo "    sudo apt install ffmpeg qbittorrent vlc"
echo ""
echo "  Para desinstalar:"
echo "    sudo apt remove videoflex"
echo "    sudo apt purge videoflex  # Elimina también config"
