# 📦 VideoFlex — Guía de Generación de Instaladores

> **VideoFlex v2.0.0** — Descargador Universal de Videos y Torrents  
> Desarrollado por Pablo F. Espinosa · PFE Computación © 2025-2026

---

## 📁 Estructura del paquete

```
videoflex-installers/
├── shared/
│   ├── videoflex.spec          ← Configuración PyInstaller (todas las plataformas)
│   └── version_info.txt        ← Metadatos del .exe (solo Windows)
├── windows/
│   ├── build_windows.bat       ← Script de build para Windows
│   └── videoflex_installer.iss ← Script Inno Setup (instalador .exe)
├── debian/
│   └── build_debian.sh         ← Script de build para Debian/Ubuntu
└── arch/
    ├── PKGBUILD                ← Receta de paquete Arch/Manjaro
    └── build_arch.sh           ← Script de build para Arch/Manjaro
```

---

## ⚙️ Cómo funciona el proceso

```
videoflex_v1.py
      │
      ▼  PyInstaller (via venv)
  VideoFlex[.exe]    ← ejecutable standalone (sin Python instalado)
      │
      ├──▶ [Windows]  Inno Setup  →  VideoFlex_Setup_2.0.0.exe
      ├──▶ [Debian]   dpkg-deb    →  videoflex_2.0.0_amd64.deb
      └──▶ [Arch]     makepkg     →  videoflex-2.0.0-1-x86_64.pkg.tar.zst
```

---

## 🪟 Windows

### Requisitos previos
| Herramienta | Versión mínima | Descarga |
|---|---|---|
| Python | 3.10+ | https://python.org |
| Inno Setup *(opcional)* | 6.x | https://jrsoftware.org/isinfo.php |

### Pasos

1. **Coloca `videoflex_v1.py` en la carpeta `windows/`**

2. **Ejecuta el script de build:**
   ```cmd
   cd windows
   build_windows.bat
   ```
   El script hace todo automáticamente:
   - Crea un `venv` aislado
   - Instala todas las dependencias
   - Compila con PyInstaller → `dist/VideoFlex.exe`
   - Si Inno Setup está instalado → genera `dist/VideoFlex_Setup_2.0.0.exe`

3. **Resultado:**
   - `dist/VideoFlex.exe` — ejecutable standalone (portable)
   - `dist/VideoFlex_Setup_2.0.0.exe` — instalador completo con accesos directos

### ¿Qué incluye el instalador `.exe`?
- Instala en `C:\Program Files\VideoFlex\`
- Acceso directo en el Menú Inicio (opcional: Escritorio)
- Desinstalador incluido
- Aviso post-instalación con dependencias (ffmpeg, yt-dlp, qBittorrent)

### Agregar ícono personalizado
1. Coloca tu ícono como `windows/assets/icon.ico`
2. En `videoflex.spec`, descomenta la línea `# icon='assets/icon.ico'`
3. En `videoflex_installer.iss`, descomenta `# SetupIconFile=assets\icon.ico`

---

## 🐧 Debian / Ubuntu

### Requisitos previos
```bash
sudo apt install python3 python3-pip python3-venv dpkg-dev
```

### Pasos

1. **Coloca `videoflex_v1.py` en la carpeta `debian/`**

2. **Dale permisos y ejecuta:**
   ```bash
   cd debian
   chmod +x build_debian.sh
   ./build_debian.sh
   ```

3. **Resultado:**
   - `debian/videoflex_2.0.0_amd64.deb`

### Instalar el paquete .deb
```bash
sudo dpkg -i videoflex_2.0.0_amd64.deb

# Si dpkg reporta dependencias faltantes:
sudo apt install -f
```

### Instalar dependencias recomendadas
```bash
sudo apt install ffmpeg qbittorrent
pip install yt-dlp
```

### Desinstalar
```bash
sudo apt remove videoflex
# o para eliminar también la config:
sudo apt purge videoflex
```

### ¿Qué instala el paquete?
| Ruta | Contenido |
|---|---|
| `/opt/videoflex/videoflex` | Ejecutable principal |
| `/usr/local/bin/videoflex` | Enlace simbólico (accesible desde terminal) |
| `/usr/share/applications/videoflex.desktop` | Entrada en el menú de aplicaciones |

---

## 🏔️ Arch Linux / Manjaro

### Requisitos previos
```bash
sudo pacman -S --needed base-devel python python-pip
```

### Pasos

1. **Coloca `videoflex_v1.py` en la carpeta `arch/`**

2. **Dale permisos y ejecuta:**
   ```bash
   cd arch
   chmod +x build_arch.sh
   ./build_arch.sh
   ```
   O directamente con makepkg:
   ```bash
   cd arch
   # Primero, copia videoflex_v1.py y los shared/ aquí
   cp ../shared/videoflex.spec .
   cp ../shared/version_info.txt .
   makepkg -si --noconfirm
   ```

3. **Resultado:**
   - `arch/videoflex-2.0.0-1-x86_64.pkg.tar.zst`

### Instalar el paquete
```bash
sudo pacman -U videoflex-2.0.0-1-x86_64.pkg.tar.zst
```

### Instalar dependencias recomendadas
```bash
sudo pacman -S ffmpeg qbittorrent
pip install yt-dlp
```

### Desinstalar
```bash
sudo pacman -R videoflex
```

### Subir a AUR *(avanzado)*
Si quieres publicar en AUR:
```bash
# Instalar herramienta AUR helper
sudo pacman -S aurpublish  # o usa git directamente

# Generar .SRCINFO (requerido por AUR)
cd arch
makepkg --printsrcinfo > .SRCINFO

# Publicar
aurpublish videoflex
```

---

## 🔧 Personalización del build

### Cambiar versión
Edita estas líneas en los archivos:

| Archivo | Variable |
|---|---|
| `shared/videoflex.spec` | No tiene versión directa (la toma del .py) |
| `shared/version_info.txt` | `filevers`, `prodvers`, `FileVersion`, `ProductVersion` |
| `windows/videoflex_installer.iss` | `#define AppVersion "2.0.0"` |
| `debian/build_debian.sh` | `APP_VERSION="2.0.0"` |
| `arch/PKGBUILD` | `pkgver=2.0.0` |

### Agregar ícono
1. Crea un ícono en estas resoluciones:
   - `assets/icon.ico` (Windows, múltiples tamaños en un solo archivo)
   - `assets/icon.png` (Linux, 256×256px mínimo)
2. Descomenta las líneas marcadas con `# Icon` en cada script.

### Excluir módulos para reducir tamaño
En `videoflex.spec`, agrega a la lista `excludes`:
```python
excludes=[
    'matplotlib', 'numpy', 'PIL', ...
    'mi_modulo_no_usado',  # Agrega aquí
]
```

---

## ❓ Solución de problemas

### Windows
| Error | Solución |
|---|---|
| `ModuleNotFoundError: flet` | Asegúrate de estar dentro del `venv_build` |
| `UPX is not available` | Instala UPX desde https://upx.github.io o ignora el warning |
| El .exe abre una ventana negra | Verifica `console=False` en el `.spec` |
| Antivirus bloquea el .exe | Firma el ejecutable con `signtool` o agrega excepción |

### Debian
| Error | Solución |
|---|---|
| `dpkg: error: need an action option` | Verifica que `dpkg-deb` esté instalado |
| `Depends: libgtk-3-0 but it is not installable` | `sudo apt update && sudo apt install libgtk-3-0` |
| La app no aparece en el menú | `sudo update-desktop-database` |

### Arch
| Error | Solución |
|---|---|
| `ERROR: Cannot find the fakeroot binary` | `sudo pacman -S fakeroot` |
| `ERROR: 'makepkg' must not be run as root` | Ejecuta como usuario normal, no con sudo |
| Conflicto con paquete existente | `sudo pacman -R videoflex-git` primero |

---

## 📋 Notas sobre las dependencias externas

VideoFlex necesita estas herramientas externas que **NO se incluyen** en el instalador:

| Herramienta | Para qué | Cómo instalar |
|---|---|---|
| **ffmpeg** | Convertir/mezclar video+audio en descargas | `winget install ffmpeg` / `apt install ffmpeg` / `pacman -S ffmpeg` |
| **yt-dlp** | Motor de descarga de videos | `pip install yt-dlp` (en todas las plataformas) |
| **qBittorrent** | Gestión de Torrents | https://www.qbittorrent.org |

El instalador avisa al usuario sobre estas dependencias al finalizar la instalación.

---

## 🔒 Firma de código *(opcional, recomendado para distribución)*

### Windows (Authenticode)
```cmd
# Requiere certificado de firma de código (comprado o autofirmado)
signtool sign /f mi_certificado.pfx /p mi_contraseña /t http://timestamp.digicert.com dist\VideoFlex.exe
signtool sign /f mi_certificado.pfx /p mi_contraseña /t http://timestamp.digicert.com dist\VideoFlex_Setup_2.0.0.exe
```

### Linux (GPG)
```bash
# Firmar el paquete .deb
dpkg-sig --sign builder videoflex_2.0.0_amd64.deb

# Firmar el paquete Arch
gpg --detach-sign videoflex-2.0.0-1-x86_64.pkg.tar.zst
```

---

*Guía generada automáticamente para VideoFlex v2.0.0*
