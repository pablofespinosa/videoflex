@echo off
setlocal EnableDelayedExpansion
chcp 65001 >nul

echo ============================================================
echo   VideoFlex - Build Script para Windows
echo   Genera: VideoFlex.exe + VideoFlex_Setup.exe
echo ============================================================
echo.

:: ── Verificar Python ──────────────────────────────────────────
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python no encontrado. Instala Python 3.10+ desde python.org
    pause & exit /b 1
)

:: ── Verificar pip ─────────────────────────────────────────────
pip --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] pip no encontrado.
    pause & exit /b 1
)

echo [1/6] Creando entorno virtual...
if exist "venv_build" rmdir /s /q venv_build
python -m venv venv_build
call venv_build\Scripts\activate.bat

echo [2/6] Instalando dependencias...
pip install --upgrade pip --quiet
pip install flet==0.80.5         --quiet
pip install pyinstaller==6.11.1  --quiet
pip install requests             --quiet
pip install pyperclip            --quiet
pip install yt-dlp               --quiet
pip install python-dateutil      --quiet

echo [3/6] Copiando archivos necesarios...
if not exist "dist" mkdir dist
copy /Y "..\shared\version_info.txt" "version_info.txt" >nul
copy /Y "..\shared\videoflex.spec"   "videoflex.spec"   >nul
copy /Y "videoflex_v1.py"            "videoflex_v1.py"  >nul 2>&1

:: Copiar ícono si existe
if exist "assets\icon.ico" (
    echo    Icono encontrado: assets\icon.ico
) else (
    echo    [AVISO] No se encontro assets\icon.ico - el .exe usara icono por defecto
    echo    Puedes agregar un icono en assets\icon.ico y descomentar la linea en el .spec
)

echo [4/6] Compilando con PyInstaller...
pyinstaller videoflex.spec --clean --noconfirm
if errorlevel 1 (
    echo [ERROR] PyInstaller fallo. Revisa los mensajes anteriores.
    call venv_build\Scripts\deactivate.bat
    pause & exit /b 1
)

echo [5/6] Verificando ejecutable generado...
if not exist "dist\VideoFlex.exe" (
    echo [ERROR] No se genero dist\VideoFlex.exe
    pause & exit /b 1
)
echo    OK: dist\VideoFlex.exe generado correctamente.

echo [6/6] Generando instalador con Inno Setup...
:: Buscar Inno Setup en rutas comunes
set INNO_PATH=
for %%P in (
    "C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
    "C:\Program Files\Inno Setup 6\ISCC.exe"
    "C:\Program Files (x86)\Inno Setup 5\ISCC.exe"
) do (
    if exist %%P set INNO_PATH=%%P
)

if defined INNO_PATH (
    echo    Inno Setup encontrado: !INNO_PATH!
    copy /Y "..\windows\videoflex_installer.iss" "videoflex_installer.iss" >nul
    !INNO_PATH! videoflex_installer.iss
    if errorlevel 1 (
        echo [AVISO] Inno Setup fallo. El .exe standalone sigue disponible en dist\
    ) else (
        echo    OK: Instalador generado en dist\VideoFlex_Setup.exe
    )
) else (
    echo.
    echo [AVISO] Inno Setup no encontrado.
    echo    Para generar el instalador .exe:
    echo    1. Descarga Inno Setup desde https://jrsoftware.org/isinfo.php
    echo    2. Instala y vuelve a ejecutar este script
    echo.
    echo    El ejecutable standalone esta disponible en: dist\VideoFlex.exe
)

call venv_build\Scripts\deactivate.bat

echo.
echo ============================================================
echo   BUILD COMPLETADO
echo   Ejecutable:  dist\VideoFlex.exe
if defined INNO_PATH (
echo   Instalador:  dist\VideoFlex_Setup.exe
)
echo ============================================================
pause
