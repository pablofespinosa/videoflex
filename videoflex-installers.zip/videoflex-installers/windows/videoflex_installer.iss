; ============================================================
;  VideoFlex - Script de instalación para Inno Setup 6
;  Genera: VideoFlex_Setup.exe
; ============================================================

#define AppName      "VideoFlex"
#define AppVersion   "2.0.0"
#define AppPublisher "PFE Computación"
#define AppAuthor    "Pablo F. Espinosa"
#define AppURL       "https://github.com/pfe-computacion/videoflex"
#define AppExeName   "VideoFlex.exe"
#define AppDesc      "Descargador Universal de Videos y Torrents"
#define AppYear      "2025-2026"

[Setup]
; Identificador único (no cambiar entre versiones)
AppId={{B3A1C2D4-5E6F-7890-ABCD-EF1234567890}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} {#AppVersion}
AppPublisher={#AppPublisher}
AppPublisherURL={#AppURL}
AppSupportURL={#AppURL}
AppUpdatesURL={#AppURL}
AppCopyright=© {#AppPublisher} {#AppYear}
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
AllowNoIcons=yes
; Compresión máxima
Compression=lzma2/ultra64
SolidCompression=yes
; Requiere admin para instalar en Program Files
PrivilegesRequired=admin
; Arquitectura
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
; Output
OutputDir=dist
OutputBaseFilename=VideoFlex_Setup_{#AppVersion}
; Ícono del instalador (descomentar si tienes el ícono)
; SetupIconFile=assets\icon.ico
; Idioma y aspecto
ShowLanguageDialog=no
WizardStyle=modern
WizardResizable=yes
; Información de versión
VersionInfoVersion={#AppVersion}
VersionInfoCompany={#AppPublisher}
VersionInfoDescription={#AppDesc}
VersionInfoCopyright=© {#AppPublisher} {#AppYear}
VersionInfoProductName={#AppName}
VersionInfoProductVersion={#AppVersion}

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon";    Description: "Crear acceso directo en el {cm:DesktopFolder}"; GroupDescription: "Accesos directos:"; Flags: unchecked
Name: "startmenuicon";  Description: "Crear acceso directo en el Menú Inicio";         GroupDescription: "Accesos directos:"; Flags: checkedonce
Name: "quicklaunch";    Description: "Agregar a la barra de tareas (anclar)";          GroupDescription: "Accesos directos:"; Flags: unchecked

[Files]
; Ejecutable principal (generado por PyInstaller)
Source: "dist\VideoFlex.exe"; DestDir: "{app}"; Flags: ignoreversion

; Archivos adicionales opcionales
; Source: "assets\icon.ico";  DestDir: "{app}\assets"; Flags: ignoreversion
; Source: "README.txt";       DestDir: "{app}";         Flags: ignoreversion isreadme
; Source: "LICENSE.txt";      DestDir: "{app}";         Flags: ignoreversion

[Icons]
Name: "{group}\{#AppName}";              Filename: "{app}\{#AppExeName}"; Comment: "{#AppDesc}"
Name: "{group}\Desinstalar {#AppName}";  Filename: "{uninstallexe}"
Name: "{autodesktop}\{#AppName}";        Filename: "{app}\{#AppExeName}"; Tasks: desktopicon; Comment: "{#AppDesc}"

[Run]
Filename: "{app}\{#AppExeName}"; \
    Description: "Iniciar {#AppName} ahora"; \
    Flags: nowait postinstall skipifsilent

[UninstallDelete]
; Limpiar archivos de configuración al desinstalar (opcional)
; Descomentar si se quiere limpiar la config del usuario:
; Type: files; Name: "{userdocs}\.videoflex_config.json"
; Type: files; Name: "{userdocs}\.videoflex_history.json"
Type: filesandordirs; Name: "{app}"

[Code]
// ── Verificar que no haya una instancia corriendo antes de instalar ──
function InitializeSetup(): Boolean;
var
  ResultCode: Integer;
begin
  Result := True;
end;

// ── Mensaje de bienvenida personalizado ──
function GetWelcomeMsg(Param: String): String;
begin
  Result := 'Bienvenido al instalador de ' + ExpandConstant('{#AppName}') + ' ' +
            ExpandConstant('{#AppVersion}') + #13#10 +
            #13#10 +
            '{#AppDesc}' + #13#10 +
            #13#10 +
            'Desarrollado por {#AppAuthor}' + #13#10 +
            '© {#AppPublisher} {#AppYear}';
end;

// ── Aviso de dependencias externas post-instalación ──
procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssDone then
  begin
    MsgBox(
      'Instalación completada.' + #13#10 + #13#10 +
      'Para usar todas las funciones de VideoFlex, asegúrate de tener instalados:' + #13#10 +
      #13#10 +
      '• ffmpeg  →  https://ffmpeg.org/download.html' + #13#10 +
      '• yt-dlp  →  pip install yt-dlp' + #13#10 +
      '• qBittorrent (para Torrents)  →  https://www.qbittorrent.org' + #13#10,
      mbInformation,
      MB_OK
    );
  end;
end;
