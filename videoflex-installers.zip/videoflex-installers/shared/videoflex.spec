# -*- mode: python ; coding: utf-8 -*-
# PyInstaller spec file para VideoFlex
# Usar con: pyinstaller videoflex.spec

import sys
import os
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

block_cipher = None

# Recolectar todos los datos de flet (assets, fuentes, etc.)
flet_datas = collect_data_files('flet', include_py_files=False)

a = Analysis(
    ['videoflex_v1.py'],
    pathex=['.'],
    binaries=[],
    datas=flet_datas,
    hiddenimports=[
        # Flet internals
        'flet',
        'flet.controls',
        'flet.messaging',
        'flet_core',
        'flet_runtime',
        # App dependencies
        'requests',
        'requests.adapters',
        'requests.packages',
        'urllib3',
        'urllib3.util',
        'urllib3.util.retry',
        'certifi',
        'charset_normalizer',
        'idna',
        # pyperclip
        'pyperclip',
        # tkinter
        'tkinter',
        'tkinter.filedialog',
        '_tkinter',
        # yt-dlp (importado dinámicamente en el código)
        'yt_dlp',
        'yt_dlp.extractor',
        'yt_dlp.downloader',
        'yt_dlp.postprocessor',
        # stdlib extras
        'json',
        'pathlib',
        'threading',
        'asyncio',
        'dataclasses',
        'enum',
        'concurrent.futures',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'matplotlib',
        'numpy',
        'PIL',
        'scipy',
        'pandas',
        'IPython',
        'jupyter',
        'PyQt5',
        'PyQt6',
        'PySide2',
        'PySide6',
        'wx',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='VideoFlex',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,           # Sin ventana de consola negra
    disable_windowed_traceback=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    # icon='assets/icon.ico',  # Descomentar si tienes ícono
    version='version_info.txt',  # Descomentar si tienes version_info.txt
)
