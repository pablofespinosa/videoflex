#!/usr/bin/env bash
# =============================================================
#  VideoFlex - Build Script para Debian/Ubuntu
#  Genera: videoflex_2.0.0_amd64.deb
#  Uso:    chmod +x build_debian.sh && ./build_debian.sh
# =============================================================
set -euo pipefail

APP_NAME="videoflex"
APP_VERSION="2.0.0"
APP_ARCH="amd64"
PKG_NAME="${APP_NAME}_${APP_VERSION}_${APP_ARCH}"
INSTALL_DIR="/opt/videoflex"
DESKTOP_DIR="/usr/share/applications"
ICON_DIR="/usr/share/pixmaps"

# Colores para output
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
info()  { echo -e "${BLUE}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

echo "============================================================"
echo "  VideoFlex - Build Script para Debian/Ubuntu"
echo "  Genera: ${PKG_NAME}.deb"
echo "============================================================"
echo

# ── Verificar dependencias del sistema ────────────────────────
info "Verificando dependencias del sistema..."
for cmd in python3 pip3 dpkg-deb; do
    command -v "$cmd" &>/dev/null || error "$cmd no encontrado. Instala con: sudo apt install python3 python3-pip dpkg"
done

PYTHON_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
info "Python $PYTHON_VERSION detectado."
[[ "${PYTHON_VERSION/./}" -lt "310" ]] && error "Se requiere Python 3.10 o superior."

# ── Crear entorno virtual ──────────────────────────────────────
info "Creando entorno virtual..."
VENV_DIR="venv_build_deb"
[[ -d "$VENV_DIR" ]] && rm -rf "$VENV_DIR"
python3 -m venv "$VENV_DIR"
source "$VENV_DIR/bin/activate"

# ── Instalar dependencias ──────────────────────────────────────
info "Instalando dependencias Python..."
pip install --upgrade pip --quiet
pip install flet==0.80.5        --quiet
pip install pyinstaller==6.11.1 --quiet
pip install requests            --quiet
pip install pyperclip           --quiet
pip install yt-dlp              --quiet
pip install python-dateutil     --quiet
ok "Dependencias instaladas."

# ── Compilar con PyInstaller ───────────────────────────────────
info "Compilando con PyInstaller..."
cp ../shared/videoflex.spec .
cp ../shared/version_info.txt .

# En Linux el spec no usa version_info.txt (es solo para Windows), parchearlo
sed -i "s/version='version_info.txt',/# version='version_info.txt',  # Solo Windows/" videoflex.spec

pyinstaller videoflex.spec --clean --noconfirm \
    --distpath ./dist_linux \
    --workpath ./build_linux

[[ -f "dist_linux/VideoFlex" ]] || error "PyInstaller no generó el ejecutable."
ok "Ejecutable generado: dist_linux/VideoFlex"

# ── Crear estructura del paquete .deb ─────────────────────────
info "Construyendo estructura del paquete .deb..."
DEB_ROOT="${PKG_NAME}"
[[ -d "$DEB_ROOT" ]] && rm -rf "$DEB_ROOT"

mkdir -p "${DEB_ROOT}/DEBIAN"
mkdir -p "${DEB_ROOT}${INSTALL_DIR}"
mkdir -p "${DEB_ROOT}${DESKTOP_DIR}"
mkdir -p "${DEB_ROOT}/usr/local/bin"
# mkdir -p "${DEB_ROOT}${ICON_DIR}"  # Descomentar si tienes ícono

# Copiar ejecutable
cp dist_linux/VideoFlex "${DEB_ROOT}${INSTALL_DIR}/videoflex"
chmod 755 "${DEB_ROOT}${INSTALL_DIR}/videoflex"

# Calcular tamaño instalado (en KB)
INSTALLED_SIZE=$(du -sk "${DEB_ROOT}${INSTALL_DIR}" | cut -f1)

# Symlink en /usr/local/bin para que sea accesible desde terminal
cat > "${DEB_ROOT}/usr/local/bin/videoflex" <<'EOF'
#!/bin/bash
exec /opt/videoflex/videoflex "$@"
EOF
chmod 755 "${DEB_ROOT}/usr/local/bin/videoflex"

# Archivo .desktop (menú de aplicaciones)
cat > "${DEB_ROOT}${DESKTOP_DIR}/videoflex.desktop" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=VideoFlex
GenericName=Descargador de Videos y Torrents
Comment=Descarga videos de YouTube, TikTok, Instagram y gestiona Torrents
Exec=/opt/videoflex/videoflex %U
# Icon=videoflex
Terminal=false
Categories=Network;FileTransfer;Video;
Keywords=video;youtube;torrent;download;descargar;
StartupNotify=true
StartupWMClass=VideoFlex
MimeType=x-scheme-handler/magnet;
EOF

# Control del paquete
cat > "${DEB_ROOT}/DEBIAN/control" <<EOF
Package: ${APP_NAME}
Version: ${APP_VERSION}
Section: net
Priority: optional
Architecture: ${APP_ARCH}
Installed-Size: ${INSTALLED_SIZE}
Depends: libgtk-3-0, libglib2.0-0, libgdk-pixbuf-2.0-0, libpango-1.0-0, libcairo2, libx11-6, libc6 (>= 2.17)
Recommends: ffmpeg, qbittorrent
Maintainer: Pablo F. Espinosa <contacto@pfe-computacion.com>
Homepage: https://github.com/pfe-computacion/videoflex
Description: Descargador Universal de Videos y Torrents
 VideoFlex es una aplicación multiplataforma que permite descargar
 videos de YouTube, TikTok, Instagram, Facebook y otros sitios, así
 como gestionar descargas de Torrents a través de qBittorrent.
 .
 Características:
  - Descarga de videos en múltiples calidades (hasta 4K)
  - Sistema anti-bloqueo con soporte de cookies
  - Gestión de Torrents integrada
  - Historial y estadísticas de descarga
  - Interfaz gráfica moderna y responsiva
EOF

# Script post-instalación
cat > "${DEB_ROOT}/DEBIAN/postinst" <<'EOF'
#!/bin/bash
set -e
# Actualizar caché de .desktop
if command -v update-desktop-database &>/dev/null; then
    update-desktop-database /usr/share/applications || true
fi
# Asociar magnet links
if command -v xdg-mime &>/dev/null; then
    xdg-mime default videoflex.desktop x-scheme-handler/magnet || true
fi
echo "VideoFlex instalado correctamente."
echo "Dependencias recomendadas: ffmpeg, qbittorrent"
echo "  sudo apt install ffmpeg qbittorrent"
exit 0
EOF
chmod 755 "${DEB_ROOT}/DEBIAN/postinst"

# Script pre-desinstalación
cat > "${DEB_ROOT}/DEBIAN/prerm" <<'EOF'
#!/bin/bash
set -e
# Eliminar asociación de magnet links
if command -v xdg-mime &>/dev/null; then
    xdg-mime uninstall /usr/share/applications/videoflex.desktop 2>/dev/null || true
fi
exit 0
EOF
chmod 755 "${DEB_ROOT}/DEBIAN/prerm"

# ── Construir el .deb ──────────────────────────────────────────
info "Generando paquete .deb..."
dpkg-deb --build --root-owner-group "${DEB_ROOT}"

[[ -f "${PKG_NAME}.deb" ]] || error "No se generó el paquete .deb"
ok "Paquete generado: ${PKG_NAME}.deb"

# Verificar el paquete
info "Verificando paquete con dpkg-deb..."
dpkg-deb --info "${PKG_NAME}.deb"

# ── Limpieza ───────────────────────────────────────────────────
deactivate
rm -rf "$VENV_DIR" "$DEB_ROOT" dist_linux build_linux videoflex.spec version_info.txt

echo
echo "============================================================"
echo "  BUILD COMPLETADO"
echo "  Paquete: ${PKG_NAME}.deb"
echo
echo "  Para instalar:"
echo "    sudo dpkg -i ${PKG_NAME}.deb"
echo "    sudo apt install -f    # Resolver dependencias si es necesario"
echo
echo "  Para desinstalar:"
echo "    sudo apt remove videoflex"
echo "============================================================"
