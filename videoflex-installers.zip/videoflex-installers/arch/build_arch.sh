#!/usr/bin/env bash
# =============================================================
#  VideoFlex - Build Script para Arch Linux / Manjaro
#  Genera: videoflex-2.0.0-1-x86_64.pkg.tar.zst
#  Uso:    chmod +x build_arch.sh && ./build_arch.sh
# =============================================================
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; NC='\033[0m'
info()  { echo -e "${BLUE}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*"; exit 1; }

echo "============================================================"
echo "  VideoFlex - Build Script para Arch Linux / Manjaro"
echo "  Genera: videoflex-2.0.0-1-x86_64.pkg.tar.zst"
echo "============================================================"
echo

# ── Verificar dependencias ─────────────────────────────────────
info "Verificando dependencias del sistema..."
for cmd in python makepkg; do
    command -v "$cmd" &>/dev/null || error "'$cmd' no encontrado."
done

# Verificar base-devel (necesario para makepkg)
if ! pacman -Qi base-devel &>/dev/null; then
    warn "base-devel no está instalado. Instalando..."
    sudo pacman -S --needed --noconfirm base-devel || error "No se pudo instalar base-devel"
fi

# ── Copiar archivos fuente al directorio arch/ ─────────────────
info "Preparando archivos fuente..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Copiar el .py fuente
if [[ -f "${SCRIPT_DIR}/../videoflex_v1.py" ]]; then
    cp "${SCRIPT_DIR}/../videoflex_v1.py" "${SCRIPT_DIR}/"
    ok "videoflex_v1.py copiado."
elif [[ -f "${SCRIPT_DIR}/videoflex_v1.py" ]]; then
    ok "videoflex_v1.py ya presente."
else
    error "No se encontró videoflex_v1.py. Colócalo en el mismo directorio que build_arch.sh"
fi

# Copiar spec y version_info
cp "${SCRIPT_DIR}/../shared/videoflex.spec"   "${SCRIPT_DIR}/"
cp "${SCRIPT_DIR}/../shared/version_info.txt" "${SCRIPT_DIR}/"
ok "Archivos de build copiados."

# ── Ejecutar makepkg ───────────────────────────────────────────
info "Ejecutando makepkg..."
cd "${SCRIPT_DIR}"

# --syncdeps instala las makedepends automáticamente
# --clean    limpia el directorio de build tras terminar
# --noconfirm no pide confirmación para instalar makedepends
makepkg -s --clean --noconfirm 2>&1

# ── Verificar resultado ────────────────────────────────────────
PKG_FILE=$(ls videoflex-*.pkg.tar.zst 2>/dev/null | head -1 || true)
[[ -z "$PKG_FILE" ]] && error "No se generó el paquete .pkg.tar.zst"
ok "Paquete generado: ${PKG_FILE}"

echo
echo "============================================================"
echo "  BUILD COMPLETADO"
echo "  Paquete: ${PKG_FILE}"
echo
echo "  Para instalar:"
echo "    sudo pacman -U ${PKG_FILE}"
echo
echo "  Para instalar dependencias recomendadas:"
echo "    sudo pacman -S ffmpeg qbittorrent"
echo "    pip install yt-dlp"
echo
echo "  Para desinstalar:"
echo "    sudo pacman -R videoflex"
echo "============================================================"
