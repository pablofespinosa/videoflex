@echo off
REM =============================================================
REM  VideoFlex - Build Script para Windows 10 / 11
REM  Genera: VideoFlex_Setup_1.5.0.exe  (con Inno Setup)
REM          VideoFlex.exe              (portable standalone)
REM
REM  USO:
REM    1. Coloca videoflex_v3-1.py en la carpeta padre (raiz del proyecto)
REM    2. Coloca assets\icon.ico en la carpeta padre\assets\
REM    3. Doble click en este archivo o ejecuta desde CMD
REM =============================================================

setlocal EnableDelayedExpansion
title VideoFlex - Build para Windows

REM ── Colores (solo funcionan en Windows 10+) ──────────────────
set "GREEN=[92m"
set "YELLOW=[93m"
set "RED=[91m"
set "CYAN=[96m"
set "BOLD=[1m"
set "NC=[0m"

echo.
echo   =================================================
echo     VideoFlex - Build Script para Windows 10/11
echo     Genera: VideoFlex.exe + VideoFlex_Setup_1.5.0.exe
echo   =================================================
echo.

REM ── Directorio raiz del proyecto ─────────────────────────────
set "SCRIPT_DIR=%~dp0"
set "ROOT_DIR=%SCRIPT_DIR%.."
cd /d "%ROOT_DIR%"
set "ROOT_DIR=%CD%"
cd /d "%SCRIPT_DIR%"

echo [INFO] Directorio raiz: %ROOT_DIR%
echo [INFO] Directorio build: %SCRIPT_DIR%

REM ── Verificar Python ─────────────────────────────────────────
echo.
echo [INFO] Verificando Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python no encontrado.
    echo         Descargalo desde https://python.org
    echo         Asegurate de marcar "Add Python to PATH" al instalar.
    pause & exit /b 1
)
for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PY_VER=%%v
echo [OK]    Python %PY_VER% detectado

REM ── Verificar version minima Python 3.10 ─────────────────────
python -c "import sys; exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Se requiere Python 3.10 o superior.
    pause & exit /b 1
)

REM ── Localizar videoflex_v3-1.py ──────────────────────────────
echo.
echo [INFO] Buscando videoflex_v3-1.py...
set "PY_SRC="
if exist "%ROOT_DIR%\videoflex_v3-1.py"  set "PY_SRC=%ROOT_DIR%\videoflex_v3-1.py"
if exist "%ROOT_DIR%\videoflex_v3.py"    set "PY_SRC=%ROOT_DIR%\videoflex_v3.py"
if exist "%SCRIPT_DIR%videoflex_v3-1.py" set "PY_SRC=%SCRIPT_DIR%videoflex_v3-1.py"

if "%PY_SRC%"=="" (
    echo [ERROR] No se encontro videoflex_v3-1.py
    echo         Coloca el script Python en: %ROOT_DIR%\
    pause & exit /b 1
)
echo [OK]    Fuente: %PY_SRC%

REM ── Localizar icono ───────────────────────────────────────────
set "ICON_PATH="
if exist "%ROOT_DIR%\assets\icon.ico" set "ICON_PATH=%ROOT_DIR%\assets\icon.ico"
if exist "%SCRIPT_DIR%assets\icon.ico" set "ICON_PATH=%SCRIPT_DIR%assets\icon.ico"

if "%ICON_PATH%"=="" (
    echo [WARN]  No se encontro assets\icon.ico
    echo         La app usara el icono por defecto de Python.
    echo         Para personalizar: crea assets\icon.ico junto al .py
) else (
    echo [OK]    Icono: %ICON_PATH%
)

REM ── Copiar fuentes al directorio windows\ ────────────────────
echo.
echo [INFO] Preparando archivos fuente...
copy /y "%PY_SRC%" "%SCRIPT_DIR%videoflex_v3-1.py" >nul
copy /y "%ROOT_DIR%\shared\videoflex.spec"     "%SCRIPT_DIR%videoflex.spec" >nul
copy /y "%ROOT_DIR%\shared\version_info.txt"   "%SCRIPT_DIR%version_info.txt" >nul

if exist "%ROOT_DIR%\assets" (
    xcopy /e /i /y "%ROOT_DIR%\assets" "%SCRIPT_DIR%assets\" >nul
    echo [OK]    assets\ copiado
)
echo [OK]    Archivos fuente listos

REM ── Crear entorno virtual ─────────────────────────────────────
echo.
echo [INFO] Creando entorno virtual...
if exist "%SCRIPT_DIR%venv_build" rmdir /s /q "%SCRIPT_DIR%venv_build"
python -m venv "%SCRIPT_DIR%venv_build"
if errorlevel 1 ( echo [ERROR] No se pudo crear el venv & pause & exit /b 1 )
echo [OK]    Entorno virtual creado

REM ── Instalar dependencias ─────────────────────────────────────
echo.
echo [INFO] Instalando dependencias (puede tardar varios minutos)...
call "%SCRIPT_DIR%venv_build\Scripts\activate.bat"

python -m pip install --upgrade pip --quiet
python -m pip install "flet>=0.21.0"      --quiet
python -m pip install "pyinstaller>=6.0"  --quiet
python -m pip install requests             --quiet
python -m pip install pyperclip            --quiet
python -m pip install psutil               --quiet
python -m pip install yt-dlp              --quiet
echo [OK]    Dependencias instaladas

REM ── Parchear spec para Windows ───────────────────────────────
echo.
echo [INFO] Configurando PyInstaller spec...
cd /d "%SCRIPT_DIR%"

REM Habilitar icono si existe
if not "%ICON_PATH%"=="" (
    python -c "
import re
with open('videoflex.spec','r') as f: c=f.read()
c=c.replace(\"# icon='assets/icon.ico',\", \"icon='assets/icon.ico',\")
c=c.replace(\"# version='version_info.txt',\", \"version='version_info.txt',\")
with open('videoflex.spec','w') as f: f.write(c)
print('[OK]    Icono habilitado en spec')
"
) else (
    python -c "
with open('videoflex.spec','r') as f: c=f.read()
c=c.replace(\"# version='version_info.txt',\", \"version='version_info.txt',\")
with open('videoflex.spec','w') as f: f.write(c)
print('[OK]    version_info habilitado en spec')
"
)

REM ── Compilar con PyInstaller ──────────────────────────────────
echo.
echo [INFO] Compilando con PyInstaller...
echo        (Este paso puede tardar 3-8 minutos dependiendo del equipo)
echo.

pyinstaller videoflex.spec ^
    --clean ^
    --noconfirm ^
    --distpath "%SCRIPT_DIR%dist" ^
    --workpath "%SCRIPT_DIR%build_tmp"

if not exist "%SCRIPT_DIR%dist\VideoFlex.exe" (
    echo [ERROR] PyInstaller no genero el ejecutable.
    echo         Revisa los mensajes de error arriba.
    call deactivate
    pause & exit /b 1
)
echo.
echo [OK]    Ejecutable: dist\VideoFlex.exe

REM ── Crear instalador con Inno Setup (opcional) ────────────────
echo.
set "INNO_EXE="
if exist "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" set "INNO_EXE=C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
if exist "C:\Program Files\Inno Setup 6\ISCC.exe"       set "INNO_EXE=C:\Program Files\Inno Setup 6\ISCC.exe"

if "%INNO_EXE%"=="" (
    echo [WARN]  Inno Setup no encontrado — se omite la generacion del .exe instalador.
    echo         Descargalo desde: https://jrsoftware.org/isinfo.php
    echo         Luego corre manualmente: ISCC.exe videoflex_installer.iss
) else (
    echo [INFO] Generando instalador con Inno Setup...
    "%INNO_EXE%" "%SCRIPT_DIR%videoflex_installer.iss"
    if errorlevel 1 (
        echo [WARN]  Inno Setup reporto un error. Revisa videoflex_installer.iss
    ) else (
        echo [OK]    Instalador: dist\VideoFlex_Setup_1.5.0.exe
    )
)

REM ── Limpieza ──────────────────────────────────────────────────
echo.
echo [INFO] Limpiando archivos temporales...
call deactivate
if exist "%SCRIPT_DIR%venv_build"   rmdir /s /q "%SCRIPT_DIR%venv_build"
if exist "%SCRIPT_DIR%build_tmp"    rmdir /s /q "%SCRIPT_DIR%build_tmp"
if exist "%SCRIPT_DIR%videoflex.spec"       del /q "%SCRIPT_DIR%videoflex.spec"
if exist "%SCRIPT_DIR%version_info.txt"     del /q "%SCRIPT_DIR%version_info.txt"
if exist "%SCRIPT_DIR%videoflex_v3-1.py"    del /q "%SCRIPT_DIR%videoflex_v3-1.py"
echo [OK]    Limpieza completada

REM ── Resultado final ───────────────────────────────────────────
echo.
echo   =================================================
echo     BUILD COMPLETADO
echo   =================================================
echo.
echo   Archivos generados en: %SCRIPT_DIR%dist\
echo.
if exist "%SCRIPT_DIR%dist\VideoFlex.exe" (
    echo   [OK] VideoFlex.exe          - Portable (sin instalador)
)
if exist "%SCRIPT_DIR%dist\VideoFlex_Setup_1.5.0.exe" (
    echo   [OK] VideoFlex_Setup_1.5.0.exe - Instalador completo
)
echo.
echo   Para ejecutar directamente:
echo     dist\VideoFlex.exe
echo.
echo   Dependencias recomendadas:
echo     ffmpeg:       https://ffmpeg.org/download.html#build-windows
echo     qBittorrent:  https://www.qbittorrent.org/download
echo     VLC:          https://www.videolan.org/vlc/
echo.
pause
