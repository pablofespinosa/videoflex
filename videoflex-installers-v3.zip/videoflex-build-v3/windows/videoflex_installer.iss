; =============================================================
;  VideoFlex - Script Inno Setup para Windows 10 / 11
;  Genera: VideoFlex_Setup_1.5.0.exe
;
;  Requiere: Inno Setup 6.x  https://jrsoftware.org/isinfo.php
;  Compilar: ISCC.exe videoflex_installer.iss
; =============================================================

#define AppName        "VideoFlex"
#define AppVersion     "1.5.0"
#define AppPublisher   "PFE Computación"
#define AppURL         "https://github.com/pfe-computacion/videoflex"
#define AppExeName     "VideoFlex.exe"
#define AppDescription "Descargador Universal de Videos y Torrents"
#define AppCopyright   "© PFE Computación 2025-2026"

[Setup]
AppId={{A1B2C3D4-E5F6-7890-ABCD-EF1234567890}
AppName={#AppName}
AppVersion={#AppVersion}
AppVerName={#AppName} v{#AppVersion}
AppPublisher={#AppPublisher}
AppPublisherURL={#AppURL}
AppCopyright={#AppCopyright}
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
DisableProgramGroupPage=yes
OutputDir=dist
OutputBaseFilename=VideoFlex_Setup_{#AppVersion}
SetupIconFile=assets\icon.ico
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
; Requiere Windows 10 o superior
MinVersion=10.0.17763
PrivilegesRequired=admin
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
UninstallDisplayIcon={app}\{#AppExeName}
UninstallDisplayName={#AppName}
ShowLanguageDialog=no
LanguageDetectionMethod=none

[Languages]
Name: "spanish"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon";   Description: "Crear acceso directo en el {cm:DesktopName}"; GroupDescription: "Accesos directos:"
Name: "quicklaunch";   Description: "Anclar a la barra de tareas";                  GroupDescription: "Accesos directos:"; Flags: unchecked
Name: "fileassoc";     Description: "Asociar enlaces magnet (torrents)";             GroupDescription: "Opciones:"; Flags: unchecked

[Files]
; Ejecutable principal
Source: "dist\{#AppExeName}"; DestDir: "{app}"; Flags: ignoreversion

; Icono (para el acceso directo y el desinstalador)
Source: "assets\icon.ico"; DestDir: "{app}"; Flags: ignoreversion; Check: FileExists(ExpandConstant('{src}\assets\icon.ico'))

; assets/ completa si existe
Source: "assets\*"; DestDir: "{app}\assets"; Flags: ignoreversion recursesubdirs createallsubdirs; Check: DirExists(ExpandConstant('{src}\assets'))

[Icons]
; Menu Inicio
Name: "{group}\{#AppName}";                Filename: "{app}\{#AppExeName}"; IconFilename: "{app}\assets\icon.ico"; Check: FileExists(ExpandConstant('{app}\assets\icon.ico'))
Name: "{group}\{#AppName}";                Filename: "{app}\{#AppExeName}"; Check: not FileExists(ExpandConstant('{app}\assets\icon.ico'))
Name: "{group}\Desinstalar {#AppName}";    Filename: "{uninstallexe}"

; Escritorio
Name: "{autodesktop}\{#AppName}";          Filename: "{app}\{#AppExeName}"; IconFilename: "{app}\assets\icon.ico"; Tasks: desktopicon; Check: FileExists(ExpandConstant('{app}\assets\icon.ico'))
Name: "{autodesktop}\{#AppName}";          Filename: "{app}\{#AppExeName}"; Tasks: desktopicon; Check: not FileExists(ExpandConstant('{app}\assets\icon.ico'))

[Registry]
; Asociacion de magnet links
Root: HKCR; Subkey: "magnet"; ValueType: string; ValueName: ""; ValueData: "URL:Magnet Protocol"; Flags: uninsdeletekey; Tasks: fileassoc
Root: HKCR; Subkey: "magnet"; ValueType: string; ValueName: "URL Protocol"; ValueData: ""; Tasks: fileassoc
Root: HKCR; Subkey: "magnet\shell\open\command"; ValueType: string; ValueName: ""; ValueData: """{app}\{#AppExeName}"" ""%1"""; Tasks: fileassoc

[Run]
; Ofrecer ejecutar la app al terminar
Filename: "{app}\{#AppExeName}"; Description: "Ejecutar {#AppName} ahora"; Flags: nowait postinstall skipifsilent

[UninstallRun]
; Limpiar asociacion de magnet al desinstalar
Filename: "cmd.exe"; Parameters: "/c reg delete HKCR\magnet /f"; Flags: runhidden; Tasks: fileassoc

[Code]
// Mostrar mensaje post-instalacion con info de dependencias
procedure CurStepChanged(CurStep: TSetupStep);
begin
  if CurStep = ssDone then
  begin
    MsgBox(
      'VideoFlex instalado correctamente.' + #13#10 + #13#10 +
      'Para aprovechar todas las funciones, instala estas herramientas:' + #13#10 + #13#10 +
      '• ffmpeg (descarga de video/audio)' + #13#10 +
      '  https://ffmpeg.org/download.html#build-windows' + #13#10 + #13#10 +
      '• qBittorrent (gestor de torrents)' + #13#10 +
      '  https://www.qbittorrent.org/download' + #13#10 + #13#10 +
      '• VLC (reproductor multimedia)' + #13#10 +
      '  https://www.videolan.org/vlc/',
      mbInformation, MB_OK
    );
  end;
end;
